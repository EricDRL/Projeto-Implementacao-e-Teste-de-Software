import { test, expect } from '@playwright/test';

/**
 * Regras da própria página (public/senha.html e public/senha.js):
 * - A senha deve ter de 8 a 20 caracteres.
 * - Deve conter ao menos uma letra maiúscula, uma minúscula e um número.
 * - Espaços não são permitidos.
 * - Se o formato for inválido: "Senha fora do padrão" (role=alert).
 * - Se o formato for válido mas a confirmação divergir: "As senhas não
 *   coincidem" (role=alert).
 * - Se tudo estiver correto: "Senha cadastrada" (role=status) e o
 *   formulário é limpo (form.reset()).
 */

async function cadastrarSenha(page, senha: string, confirmacao: string) {
  await page.goto('/senha');
  await page.getByLabel('Nova senha').fill(senha);
  await page.getByLabel('Confirmar senha').fill(confirmacao);
  await page.getByRole('button', { name: 'Cadastrar senha' }).click();
  return page.locator('#resultado');
}

test.describe('senha — caminho válido e valores-limite de tamanho', () => {
  const casosValidos = [
    {
      classe: 'limite mínimo de tamanho (8 caracteres)',
      senha: 'Abcdef1g',
    },
    {
      classe: 'limite máximo de tamanho (20 caracteres)',
      senha: 'A' + 'a'.repeat(17) + '12',
    },
    {
      classe: 'tamanho intermediário válido',
      senha: 'SenhaSegura123!',
    },
  ];

  for (const caso of casosValidos) {
    test(`senha com ${caso.senha.length} caracteres — ${caso.classe}`, async ({ page }) => {
      const resultado = await cadastrarSenha(page, caso.senha, caso.senha);
      await expect(resultado).toBeVisible();
      await expect(resultado).toHaveAttribute('role', 'status');
      await expect(resultado).toHaveText('Senha cadastrada');
    });
  }

  test('formulário é limpo após cadastro bem-sucedido', async ({ page }) => {
    const senha = 'Senha123';
    await cadastrarSenha(page, senha, senha);
    await expect(page.getByLabel('Nova senha')).toHaveValue('');
    await expect(page.getByLabel('Confirmar senha')).toHaveValue('');
  });
});

test.describe('senha — classes inválidas e valores-limite de formato', () => {
  const casosFormatoInvalido = [
    {
      classe: 'abaixo do limite mínimo (7 caracteres)',
      senha: 'Ab1defg',
    },
    {
      classe: 'acima do limite máximo (21 caracteres)',
      senha: 'A' + 'a'.repeat(18) + '12',
    },
    {
      classe: 'sem letra maiúscula',
      senha: 'senha123',
    },
    {
      classe: 'sem letra minúscula',
      senha: 'SENHA123',
    },
    {
      classe: 'sem número',
      senha: 'SenhaSegura',
    },
    {
      classe: 'contém espaço',
      senha: 'Senha 123',
    },
    {
      classe: 'campo vazio',
      senha: '',
    },
  ];

  for (const caso of casosFormatoInvalido) {
    test(`senha "${caso.senha || '(vazia)'}" — ${caso.classe}`, async ({ page }) => {
      const resultado = await cadastrarSenha(page, caso.senha, caso.senha);
      await expect(resultado).toBeVisible();
      await expect(resultado).toHaveAttribute('role', 'alert');
      await expect(resultado).toHaveText('Senha fora do padrão');
    });
  }

  test('formato válido, mas confirmação não coincide', async ({ page }) => {
    const resultado = await cadastrarSenha(page, 'Senha123', 'Senha1234');
    await expect(resultado).toBeVisible();
    await expect(resultado).toHaveAttribute('role', 'alert');
    await expect(resultado).toHaveText('As senhas não coincidem');
  });
});
