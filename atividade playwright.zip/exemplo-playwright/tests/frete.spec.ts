import { test, expect } from '@playwright/test';

/**
 * Regras da própria página (public/frete.html e public/frete.js):
 * - CEP deve ter exatamente 8 dígitos numéricos.
 * - Valor deve ser numérico, maior que zero, com no máximo 2 casas decimais
 *   (separador "," ou ".").
 * - CEP iniciado por "8": frete de R$ 15,00.
 * - Demais CEPs: frete de R$ 25,00.
 * - Pedidos com valor >= R$ 200,00: frete grátis (independe do CEP).
 * - Qualquer entrada fora do formato aceito: "Dados inválidos" (role=alert).
 */

async function calcularFrete(page, cep: string, valor: string) {
  await page.goto('/frete');
  await page.getByLabel('CEP').fill(cep);
  await page.getByLabel('Valor do pedido').fill(valor);
  await page.getByRole('button', { name: 'Calcular frete' }).click();
  return page.locator('#resultado');
}

test.describe('frete — caminhos válidos e limite do valor mínimo do pedido', () => {
  const casosValidos = [
    {
      classe: 'CEP iniciado em 8, valor abaixo de R$200',
      cep: '80000000',
      valor: '50,00',
      texto: 'Frete: R$ 15,00',
    },
    {
      classe: 'CEP não iniciado em 8, valor abaixo de R$200',
      cep: '01310000',
      valor: '50,00',
      texto: 'Frete: R$ 25,00',
    },
    {
      classe: 'valor logo abaixo do limite de frete grátis (R$199,99)',
      cep: '01310000',
      valor: '199,99',
      texto: 'Frete: R$ 25,00',
    },
    {
      classe: 'valor no limite exato do frete grátis (R$200,00)',
      cep: '01310000',
      valor: '200,00',
      texto: 'Frete grátis',
    },
    {
      classe: 'valor acima do limite de frete grátis (R$250,00)',
      cep: '80000000',
      valor: '250,00',
      texto: 'Frete grátis',
    },
    {
      classe: 'valor mínimo positivo aceito (R$0,01)',
      cep: '01310000',
      valor: '0,01',
      texto: 'Frete: R$ 25,00',
    },
    {
      classe: 'separador decimal com ponto também é aceito',
      cep: '80000000',
      valor: '50.00',
      texto: 'Frete: R$ 15,00',
    },
    {
      classe: 'CEP iniciado em 8 com valor sem casas decimais',
      cep: '89999999',
      valor: '10',
      texto: 'Frete: R$ 15,00',
    },
  ];

  for (const caso of casosValidos) {
    test(`CEP ${caso.cep} / valor ${caso.valor} — ${caso.classe}`, async ({ page }) => {
      const resultado = await calcularFrete(page, caso.cep, caso.valor);
      await expect(resultado).toBeVisible();
      await expect(resultado).toHaveAttribute('role', 'status');
      await expect(resultado).toHaveText(caso.texto);
    });
  }
});

test.describe('frete — classes inválidas e valores-limite de formato', () => {
  const casosInvalidos = [
    { classe: 'CEP com 7 dígitos (abaixo do limite)', cep: '8000000', valor: '50,00' },
    { classe: 'CEP com 9 dígitos (acima do limite)', cep: '800000000', valor: '50,00' },
    { classe: 'CEP com letras', cep: '8000000A', valor: '50,00' },
    { classe: 'CEP vazio', cep: '', valor: '50,00' },
    { classe: 'valor igual a zero (deve ser > 0)', cep: '80000000', valor: '0,00' },
    { classe: 'valor negativo', cep: '80000000', valor: '-10,00' },
    { classe: 'valor com 3 casas decimais', cep: '80000000', valor: '10,999' },
    { classe: 'valor não numérico', cep: '80000000', valor: 'abc' },
    { classe: 'valor vazio', cep: '80000000', valor: '' },
  ];

  for (const caso of casosInvalidos) {
    test(`CEP "${caso.cep}" / valor "${caso.valor}" — ${caso.classe}`, async ({ page }) => {
      const resultado = await calcularFrete(page, caso.cep, caso.valor);
      await expect(resultado).toBeVisible();
      await expect(resultado).toHaveAttribute('role', 'alert');
      await expect(resultado).toHaveText('Dados inválidos');
    });
  }
});
